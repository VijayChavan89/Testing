*** Settings ***
Library       CopadoAI
Library       ../libraries/ACNCopadoAI.py
Library       QWeb
Library       DateTime 
Library       QForce
Library       Collections
Library       String
Library       DataDriver            reader_class=${CURDIR}/../libraries/SalesforceDataReader.py    data_file=${yaml_path}

Variables        ${yaml_path}
Resource          ../resources/common.robot
Resource          ../resources/actions/HarishTestActionRobot.robot
#Suite Setup       Start Agent
Suite Setup       Setup Agent Testing
Suite Teardown    End Suite
Test Template     Engage Conversation


*** Variables ***
${yaml_path}=                       ${CURDIR}/../${data_file}

*** Test Cases ***
    Conversation Test        ${message}     ${response}    ${context}    ${allow_variants}    ${eval_metrics}    ${action_names}    ${action_instruction}

*** Keywords ***

Setup Agent Testing
    [Documentation]    Initializes the agent testing environment and selects the specified agent
    Start Agent
    # Select the agent specified in the YAML file
    # The ${agent.name} variable will be loaded from the YAML file's agent section
    Select Agent       B2B Asset Agent
    # Optional: Clear any existing chat history
  #  Clear Chat history


Engage Conversation
    [Arguments]           ${message}     ${response}    ${context}    ${allow_variants}    ${eval_metrics}    ${action_names}   ${action_instruction}
    [Documentation]    Engage in a conversation with the agent and validate the response.
    &{output}=    Create Dictionary    expected_message=${message}    expected_response=${response}    context=${context}    allow_variants=${allow_variants}    eval_metrics=${eval_metrics}    action_names=${action_names}    action_instruction=${action_instruction}
    @{errors}=    Create List

    ${actual_message}=     Generate Variant    ${message}    ${allow_variants}
    ${actual_response}=    Send Message    ${actual_message} ${action_instruction}

    # Check if response contains Session ID pattern and retry if it does
    ${contains_session}=    Run Keyword And Return Status    
    ...    Should Match Regexp    ${actual_response}    .*\\(Session ID: [a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\\).*
    
    ${actual_response}=    Run Keyword If    ${contains_session}    
    ...    Send Message    ${message} ${action_instruction}
    ...    ELSE    Set Variable    ${actual_response}

    Set to Dictionary    ${output}    actual_response=${actual_response}

    # Evaluate the response
    TRY
        ${metric_results}=     Get Evaluation Metrics      ${eval_metrics}    ${message}    ${response}    ${actual_response}    ${context}
        Set to Dictionary    ${output}    metric_results=${metric_results}
        Evaluate Metrics    ${metric_results}
    EXCEPT
        Append To List    ${errors}    Response Evaluation Failed
    END
    
    # Execute actions if any
    FOR    ${action}    IN    @{action_names}
        TRY
            Run Keyword    ${action}    ${actual_response}
        EXCEPT
            Append To List    ${errors}    Action `${action}` Execution Failed
            SwitchWindow                1
        END
    END


    # Check if any errors occurred
    ${error_count}=    Get Length    ${errors}
    Set to Dictionary    ${output}    error_count=${error_count}    errors=${errors}
    Set Test Variable    ${test_output}    ${output}
    Run Keyword If    ${error_count} > 0    Fail    The following issues occurred:\n@{errors}