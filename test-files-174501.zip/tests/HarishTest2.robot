*** Settings ***
Library    QWeb
Library    QForce
Library    CopadoAI
Library    String

Variables         ${yaml_path}

*** Variables ***
${BROWSER}               chrome
${home_url}               ${login_url}/lightning/page/home

*** Keywords ***

#these inputs should be taken from the yml file     
Verify Created Discount
    [Documentation]      Keyword to validate back end opportunity records created by an agent 
    [Arguments]    ${opportunity_id}                      #opportunity record you are validating 
    ...            ${account_name}=${account.true_name}        # Name of the account the rfp is attatched to 
    ...            ${close_date}=${opportunity.close_date}                # close date of the opportunity 
    ...            ${stage}=${opportunity.stage}                   # state of the opportunity - auto set to proposal when opportunity is created



    # next prompt - recommended discount for this quote - Yes, Apply to all products

    VerifyText      Related
    ClickText       Related
    Sleep           10

    VerifyText    Discount (Percentage)
    VerifyText    8.25%
    VerifyText    5.00%