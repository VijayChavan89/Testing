import os
import xlsxwriter
from robot.libraries.BuiltIn import BuiltIn

class AgentReportingListener:
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    ROBOT_LISTENER_API_VERSION = 3

    def __init__(self, output_file='agent_results.xlsx'):
        output_dir = '/home/executor/execution/output/'

        # Ensure output_name is just a filename (no stray dirs)
        filename = os.path.basename(output_file)

        # Final path
        self.output_path = os.path.join(output_dir, filename)

        # Create workbook & worksheet
        self.workbook  = xlsxwriter.Workbook(self.output_path)
        self.worksheet = self.workbook.add_worksheet('Results')
        # Write header row
        #headers = ['Test Case', 'Status', 'Start Time', 'End Time', 'Elapsed (s)', 'Message', 'Variables']
        headers = ['Test Case', 'Status', 'Message', 'Variables']
        for col, header in enumerate(headers):
            self.worksheet.write(0, col, header)
        self._row = 1  # next row to write

    def start_test(self, data, result):
        # data.name is the test case name; result has no info yet
        self._current = {'name': data.name}

    def end_test(self, data, result):
        # result holds status, start_time, end_time, elapsed_time, message
        row = self._row
        self.worksheet.write(row, 0, data.name)
        self.worksheet.write(row, 1, result.status)
        # times come as ISO strings; elapsed_time is float seconds
        #self.worksheet.write(row, 2, str(result.start_time))
        #self.worksheet.write(row, 3, str(result.end_time))
        #self.worksheet.write_number(row, 4, str(result.elapsed_time))
        self.worksheet.write(row, 5, result.message or '')
        vars_dict = BuiltIn().get_variables(no_decoration=True)['test_output']
        self.worksheet.write(row, 6, str(vars_dict) or '')
        self._row += 1

    def close(self):
        # Finish and save the workbook when Robot finishes
        self.workbook.close()
        BuiltIn().log(f"XLSX report written to {self.output_path}", level='INFO')
