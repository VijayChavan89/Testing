from DataDriver.AbstractReaderClass import AbstractReaderClass
from DataDriver.ReaderConfig import ReaderConfig, TestCaseData
from typing import Any, Dict, List
import yaml
from jinja2 import Environment
import time
import os
import json
from robot.api import logger
from robot.libraries.BuiltIn import BuiltIn
from jinja2.exceptions import TemplateError

try:
    from simple_salesforce import Salesforce  # type: ignore  # noqa: F401
except Exception as err:  # pragma: no cover - optional dependency may be missing
    raise ImportError(
        "simple-salesforce library is required for SalesforceDataReader"
    ) from err


class SalesforceDataReader(AbstractReaderClass):
    """
    SalesforceDataReader retrieves conversation prompts from Salesforce
    and applies Jinja2 substitution using a YAML parameter file.

    Features:
    - Salesforce query support for conversation templates
    - Parameter substitution using Jinja2
    - Detailed logging and error handling using Robot Framework logger
    - Data validation and file information retrieval
    """
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    CLASS_NAME = 'SalesforceDataReader'

    ### Initialize ###
    def __init__(self, reader_config: ReaderConfig):
        """
        Initialize the reader with configuration.

        Args:
            reader_config: Configuration containing:
                - template_file: Conversation__c record id (optional)
                - record_id: Conversation__c record id (optional kwarg)
                - data_file: YAML file with substitution parameters (optional)
                - copa_domain: (optional) Copado Salesforce domain
                - copa_session_id: (optional) existing Copado Salesforce session ID
        """
        super().__init__(reader_config)
        self.kwargs = reader_config.kwargs

        # Record id can be provided via DataDriver file argument, kwargs, or a
        # Robot Framework variable. It is mandatory for execution.
        self.record_id = (
            reader_config.file
            or self.kwargs.get("record_id")
            or self._get_variable_value("${record_id}")
        )

        if not self.record_id:
            raise ValueError("record_id must be provided")

        # data_file is optional; if not provided via kwargs fall back to a
        # Robot variable of the same name
        self.data_file = self.kwargs.get("data_file") or self._get_variable_value("${data_file}")

        # Collect Copado Salesforce connection details early
        self.domain = self.kwargs.get("copa_domain") or self._get_variable_value("${copa_domain}")
        self.session_id = self.kwargs.get("copa_session_id") or self._get_variable_value("${copa_session_id}")

        self._debug(f"Domain: {self.domain}")
        self._debug(f"Session ID Provided: {'YES' if self.session_id else 'NO'}")

        if not (self.domain and self.session_id):
            raise ValueError("copa_domain and copa_session_id must be provided")

        self.parameters: Dict[str, Any] = {}

        self._debug("Initializing SalesforceDataReader")
        self._debug(f"Record Id: {self.record_id}")
        self._debug(f"Data file: {self.data_file}")

        try:
            self.parameters = self._load_parameters()
            if self.parameters:
                self._debug(f"Loaded parameters: {self.parameters}")
            else:
                self._warn("No parameters loaded - substitution will be skipped")
        except Exception as e:
            self._error(f"Initialization failed: {str(e)}")
            raise

    ### Utility Functions ###
    def _get_variable_value(self, name: str):
        return BuiltIn().get_variable_value(name)

    def _debug(self, msg: Any, newline: bool = True, stream: str = "stdout"):
        if self._get_variable_value("${LOG LEVEL}") in ["DEBUG", "TRACE"]:
            logger.console(f"[ {self.CLASS_NAME} ] {msg}", newline, stream)

    def _console(self, msg: Any, newline: bool = True, stream: str = "stdout"):
        logger.console(f"[ {self.CLASS_NAME} ] {msg}", newline, stream)

    def _warn(self, msg: Any, html: bool = False):
        logger.warn(f"[ {self.CLASS_NAME} ] {msg}", html)

    def _error(self, msg: Any, html: bool = False):
        logger.error(f"[ {self.CLASS_NAME} ] {msg}", html)



    def _load_parameters(self) -> Dict[str, Any]:
        """
        Load and validate parameters from a YAML file.

        Returns:
            A dictionary of parameters.

        Raises:
            FileNotFoundError: If the data file (YAML) does not exist.
            ValueError: If the loaded parameters are not in a dictionary format.
        """
        if not self.data_file:
            self._debug("No data file specified; skipping parameter loading.")
            return {}

        try:
            if not os.path.exists(self.data_file):
                raise FileNotFoundError(f"Data file not found: {self.data_file}")

            with open(self.data_file, 'r') as f:
                params = yaml.safe_load(f)
                if not isinstance(params, dict):
                    raise ValueError("Data file must contain a dictionary")
                return params
        except Exception as e:
            self._error(f"Parameter loading error: {str(e)}")
            raise

    def get_time_seconds(self, str):
        """Generate current timestamp in seconds as an integer"""
        return int(time.time())

    def _process_template(self, value: Any) -> Any:
        """
        Recursively process values through the Jinja2 template engine.
        
        Args:
            value: The value to process (can be str, list, dict, or other types)
        
        Returns:
            The processed value maintaining the original structure
        """
        if value is None:
            return None
            
        if isinstance(value, str):
            try:
                # Create Jinja2 environment with custom filter
                env = Environment()
                
                # Register custom filter
                env.filters['time_seconds'] = self.get_time_seconds
                
                # Create template from environment
                template = env.from_string(value)
                processed = template.render(self.parameters)
                self._debug(f"Template processing: '{value}' -> '{processed}'")
                return processed
            except Exception as e:
                self._error(f"Template processing error for '{value}': {str(e)}")
                return value
                
        if isinstance(value, list):
            return [self._process_template(item) for item in value]
            
        if isinstance(value, dict):
            return {k: self._process_template(v) for k, v in value.items()}
            
        return value

    def _apply_template_to_testcase_data(self) -> List[TestCaseData]:
        """
        Apply Jinja2 templating to replace tokens in TestCaseData objects.

        Returns:
            A list of TestCaseData objects with replaced values.
        """
        processed_test_cases: List[TestCaseData] = []
        self._debug("Applying parameter substitution to test cases...")

        for index, test_case in enumerate(self.data_table):
            try:
                # Process test case name.
                processed_name = self._process_template(test_case.test_case_name)

                # Process arguments dictionary.
                processed_arguments = {}
                if test_case.arguments:
                    for key, value in test_case.arguments.items():
                        processed_key = self._process_template(key)
                        processed_value = self._process_template(value)
                        processed_arguments[processed_key] = processed_value

                # Process tags list.
                processed_tags = None
                if test_case.tags:
                    processed_tags = [self._process_template(tag) for tag in test_case.tags]

                # Process documentation.
                processed_documentation = self._process_template(test_case.documentation)

                # Create a new TestCaseData object with processed values.
                processed_case = TestCaseData(
                    test_case_name=processed_name,
                    arguments=processed_arguments,
                    tags=processed_tags,
                    documentation=processed_documentation
                )
                processed_test_cases.append(processed_case)
                self._debug(f"Processed test case {index + 1}: {processed_case}")
            except Exception as e:
                self._error(f"Error processing test case: {str(e)}")
                # In case of error, add the original test case without substitution.
                processed_test_cases.append(test_case)

        return processed_test_cases

    def _transform_eval_metrics(self, value: str) -> List[str]:
        """Convert stored JSON metrics to a list format."""
        if not value:
            return []
        try:
            metrics = json.loads(value)
            if isinstance(metrics, dict):
                return [f"{k}({v})" for k, v in metrics.items()]
            if isinstance(metrics, list):
                return [str(m) for m in metrics]
        except Exception:
            pass
        return [str(value)]

    def _transform_action_names(self, value: str) -> List[str]:
        """Convert stored JSON actions to a list format."""
        if not value:
            return []
        try:
            names = json.loads(value)
            if isinstance(names, list):
                return [str(n) for n in names]
        except Exception:
            pass
        return [str(value)]

    def _connect_salesforce(self) -> Salesforce:
        """Connect to Salesforce using the stored session ID and domain."""
        if not (self.domain and self.session_id):
            raise ValueError("copa_domain and copa_session_id must be provided")

        return Salesforce(instance_url=self.domain, session_id=self.session_id)

    def get_data_from_source(self) -> List[TestCaseData]:
        try:
            if not self.record_id:
                raise ValueError("No record id specified")

            sf = self._connect_salesforce()
            query = (
                "SELECT Name, Prompt__c, Expected_Response__c, Response_Context__c, Allow_Variants__c, "
                "Evaluation_Metrics__c, Action_Names__c, Action_Instruction__c "
                f"FROM Conversation_Prompt__c WHERE Conversation__c = '{self.record_id}' "
                "ORDER BY Order__c ASC"
            )
            records = sf.query(query).get("records", [])

            header = [
                "*** Test Cases ***",
                "${message}",
                "${response}",
                "${context}",
                "${allow_variants}",
                "${eval_metrics}",
                "${action_names}",
                "${action_instruction}",
            ]

            self.data_table = []
            for rec in records:
                args = {
                    # Use `or ''` to avoid None values propagating to Robot Framework
                    header[1]: rec.get("Prompt__c") or "",
                    header[2]: rec.get("Expected_Response__c") or "",
                    header[3]: rec.get("Response_Context__c") or "",
                    header[4]: str(rec.get("Allow_Variants__c", False)).upper(),
                    header[5]: self._transform_eval_metrics(rec.get("Evaluation_Metrics__c")),
                    header[6]: self._transform_action_names(rec.get("Action_Names__c")),
                    header[7]: rec.get("Action_Instruction__c") or "",
                }
                self.data_table.append(
                    TestCaseData(test_case_name=rec.get("Name"), arguments=args)
                )

            processed_data = self._apply_template_to_testcase_data()
            self.data_table = processed_data
            return self.data_table

        except Exception as e:
            self._error(f"Data processing error: {str(e)}")
            raise